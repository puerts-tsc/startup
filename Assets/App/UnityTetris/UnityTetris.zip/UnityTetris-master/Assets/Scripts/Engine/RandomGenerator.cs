﻿using System;
namespace TetrisEngine
{
    public static class RandomGenerator
    {
		public static Random random = new Random();
    }
}
